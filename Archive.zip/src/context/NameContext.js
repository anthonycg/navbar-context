import React, { createContext } from "react";

const NameContext = createContext();

export default NameContext;